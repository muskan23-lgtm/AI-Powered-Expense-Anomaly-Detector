from pathlib import Path
import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
from src.analyze_expenses import detect_anomalies

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "expenses.csv"

st.set_page_config(page_title="Expense Anomaly Detector", page_icon="🔎", layout="wide")
st.title("🔎 AI-Powered Expense Anomaly Detector")
st.caption("Demo finance analytics dashboard • Synthetic data • INR")

df = pd.read_csv(DATA)
result = detect_anomalies(df)

with st.sidebar:
    st.header("Filters")
    departments = ["All"] + sorted(result["department"].dropna().unique().tolist())
    selected_department = st.selectbox("Department", departments)
    categories = ["All"] + sorted(result["category"].dropna().unique().tolist())
    selected_category = st.selectbox("Expense category", categories)
    only_flagged = st.checkbox("Show only flagged expenses", value=False)

filtered = result.copy()
if selected_department != "All":
    filtered = filtered[filtered["department"] == selected_department]
if selected_category != "All":
    filtered = filtered[filtered["category"] == selected_category]
if only_flagged:
    filtered = filtered[filtered["review_status"] == "Review"]

total_spend = filtered["amount_inr"].sum()
flagged = int((filtered["review_status"] == "Review").sum())
duplicates = int(filtered["possible_duplicate"].sum())
avg_expense = filtered["amount_inr"].mean() if len(filtered) else 0

c1,c2,c3,c4 = st.columns(4)
c1.metric("Total spend", f"₹{total_spend:,.0f}")
c2.metric("Transactions", f"{len(filtered):,}")
c3.metric("Flagged for review", f"{flagged:,}")
c4.metric("Possible duplicate rows", f"{duplicates:,}")

left,right = st.columns(2)
with left:
    st.subheader("Spend by category")
    cat_summary = filtered.groupby("category", as_index=False)["amount_inr"].sum().sort_values("amount_inr", ascending=False)
    if len(cat_summary):
        st.plotly_chart(px.bar(cat_summary, x="category", y="amount_inr", title="Total spend (INR)"), use_container_width=True)
with right:
    st.subheader("Flagged vs normal")
    status_summary = filtered["review_status"].value_counts().rename_axis("status").reset_index(name="count")
    if len(status_summary):
        st.plotly_chart(px.pie(status_summary, names="status", values="count", hole=.45), use_container_width=True)

st.subheader("Transactions for review")
display_cols = ["expense_id","date","employee_id","department","category","vendor","amount_inr","possible_duplicate","high_amount_flag","anomaly_score","review_status"]
st.dataframe(filtered[display_cols].sort_values(["anomaly_score","amount_inr"], ascending=[False,False]), use_container_width=True, hide_index=True)
st.download_button("Download filtered transactions as CSV", filtered[display_cols].to_csv(index=False).encode("utf-8"), "expense_review.csv", "text/csv")

st.info("A flag is only a signal for human review, not proof of fraud. This demo uses synthetic data and transparent heuristics.")
