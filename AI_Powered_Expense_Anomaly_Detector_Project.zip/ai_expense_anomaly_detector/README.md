# AI-Powered Expense Anomaly Detector

A beginner-friendly data analytics project that flags potentially unusual business expenses using transparent rules and statistical anomaly detection. It includes synthetic expense data, Python analysis, SQL examples, and a Streamlit dashboard.

> **Important:** This is a learning/demo project using synthetic data. A flagged transaction is not proof of fraud; it should be reviewed by a human.

## Business problem
Organizations process many employee expenses. Manually checking every claim is slow, and unusual amounts or duplicate claims can be missed. This project prioritizes transactions for review.

## Features
- Flags unusually high expenses using category-level IQR and z-score-style comparisons.
- Detects possible duplicates using employee, date, vendor, and amount.
- Uses simple rule-based signals and an Isolation Forest model when scikit-learn is installed.
- Dashboard KPIs, category summaries, flagged transaction table, and CSV export.
- SQL examples for common finance analytics questions.

## Project structure
```text
ai_expense_anomaly_detector/
├── app.py
├── requirements.txt
├── data/expenses.csv
├── src/analyze_expenses.py
├── sql/queries.sql
└── reports/interview_notes.md
```

## Run on Windows
1. Install Python 3.10+.
2. Extract the ZIP.
3. Open the extracted folder in VS Code.
4. Open Terminal → New Terminal.
5. Run:
   ```bash
   pip install -r requirements.txt
   streamlit run app.py
   ```
6. A browser tab should open with the dashboard.

If Streamlit is not available, run the standalone analysis:
```bash
python src/analyze_expenses.py
```
It writes `reports/flagged_expenses.csv` and `reports/category_summary.csv`.

## How to explain it in an interview
“I built an expense analytics tool that helps a finance team prioritize expense claims for review. I cleaned and analyzed transaction data with Python and pandas, used SQL to answer spend-related questions, and built a Streamlit dashboard. The detector flags unusual amounts and possible duplicates. It supports investigation; it does not automatically label an expense as fraud.”

## Suggested next improvements
- Replace synthetic data with an authorized, anonymized dataset.
- Add employee-level monthly baselines and configurable policy thresholds.
- Connect a Power BI dashboard and compare its metrics with Python outputs.
