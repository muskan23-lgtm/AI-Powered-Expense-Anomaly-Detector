# Interview notes: AI-Powered Expense Anomaly Detector

## 30-second explanation
I built a finance analytics dashboard that helps a company identify expense claims that may need a closer look. It analyzes transaction amounts by category, checks for possible duplicates, summarizes spending, and displays flagged items in a Streamlit dashboard.

## Business problem
Finance teams may process hundreds or thousands of claims. Manual review can be slow, and duplicate or unusually high claims may be missed. The tool prioritizes suspicious-looking rows for review rather than deciding whether fraud occurred.

## Tools used
- **Python:** project logic and analysis.
- **pandas / NumPy:** data cleaning, grouping, flags, and summary calculations.
- **SQL:** spend by category, monthly spend, duplicate claims, and high-value expense queries.
- **Streamlit:** interactive dashboard and filters.
- **Plotly:** charts.
- **IQR rule:** flags category-specific outliers beyond Q3 + 1.5 × IQR. It is a common statistical heuristic, not a company policy.

## How to run
`pip install -r requirements.txt`
`streamlit run app.py`

## Resume bullets
- Built a Python-based expense analytics tool to flag unusually high transactions and possible duplicate claims for finance-team review.
- Analyzed 900 synthetic expense records using pandas and category-level IQR rules; wrote SQL queries for spend trends and duplicate detection.
- Developed a Streamlit dashboard with department/category filters, spending KPIs, anomaly review tables, charts, and CSV export.

## Questions to prepare
1. Why did you choose this project? It connects analytics to a clear business problem: reducing manual expense-review effort.
2. How are anomalies detected? A transaction is flagged if it is a category-level IQR outlier or matches another expense on employee, date, vendor, and amount.
3. Is every flagged transaction fraud? No. A flag only identifies something worth checking; valid travel or software purchases can be large.
4. What would you improve? Use approved company data, policy-specific thresholds, employee/month baselines, explainable ML, role-based access, and a feedback loop from finance reviewers.
5. Why use SQL? SQL answers business questions like spend by category, monthly departmental spend, and possible duplicate claims.
