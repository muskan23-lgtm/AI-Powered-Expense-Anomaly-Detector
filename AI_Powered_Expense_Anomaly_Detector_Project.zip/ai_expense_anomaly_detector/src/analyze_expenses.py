from pathlib import Path
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "expenses.csv"
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

def detect_anomalies(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    # Possible duplicate: same employee/date/vendor/amount
    duplicate_cols = ["employee_id", "date", "vendor", "amount_inr"]
    df["possible_duplicate"] = df.duplicated(duplicate_cols, keep=False)

    # Category-specific robust range using IQR
    q1 = df.groupby("category")["amount_inr"].transform(lambda s: s.quantile(0.25))
    q3 = df.groupby("category")["amount_inr"].transform(lambda s: s.quantile(0.75))
    iqr = q3 - q1
    df["high_amount_flag"] = df["amount_inr"] > (q3 + 1.5 * iqr)

    # Rule-based review score; intentionally transparent
    df["anomaly_score"] = (
        df["possible_duplicate"].astype(int) * 2
        + df["high_amount_flag"].astype(int) * 2
    )
    df["review_status"] = np.where(df["anomaly_score"] > 0, "Review", "Normal")
    return df

def main():
    df = pd.read_csv(DATA)
    result = detect_anomalies(df)
    result.to_csv(REPORTS / "flagged_expenses.csv", index=False)
    summary = result.groupby("category", as_index=False).agg(
        total_spend_inr=("amount_inr", "sum"),
        average_expense_inr=("amount_inr", "mean"),
        transaction_count=("expense_id", "count"),
        flagged_count=("review_status", lambda s: (s == "Review").sum())
    )
    summary.to_csv(REPORTS / "category_summary.csv", index=False)
    print(f"Analyzed {len(result)} expenses.")
    print(f"Flagged for review: {(result['review_status'] == 'Review').sum()}")
    print(f"Reports saved in: {REPORTS}")

if __name__ == "__main__":
    main()
