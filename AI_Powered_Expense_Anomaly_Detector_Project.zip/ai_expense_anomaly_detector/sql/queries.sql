-- 1. Total spend by category
SELECT category,
       SUM(amount_inr) AS total_spend_inr,
       AVG(amount_inr) AS average_expense_inr,
       COUNT(*) AS transaction_count
FROM expenses
GROUP BY category
ORDER BY total_spend_inr DESC;

-- 2. Possible duplicate claims
SELECT employee_id, date, vendor, amount_inr, COUNT(*) AS matching_rows
FROM expenses
GROUP BY employee_id, date, vendor, amount_inr
HAVING COUNT(*) > 1
ORDER BY matching_rows DESC;

-- 3. Monthly spend by department
SELECT SUBSTR(date, 1, 7) AS expense_month,
       department,
       SUM(amount_inr) AS total_spend_inr
FROM expenses
GROUP BY SUBSTR(date, 1, 7), department
ORDER BY expense_month, total_spend_inr DESC;

-- 4. Transactions above category average by 2x (simple review heuristic)
SELECT e.*
FROM expenses e
JOIN (
    SELECT category, AVG(amount_inr) AS avg_amount
    FROM expenses
    GROUP BY category
) c ON e.category = c.category
WHERE e.amount_inr > 2 * c.avg_amount
ORDER BY e.amount_inr DESC;
